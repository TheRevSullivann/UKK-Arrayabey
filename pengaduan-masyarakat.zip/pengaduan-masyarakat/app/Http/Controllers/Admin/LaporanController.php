<?php


namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use App\Models\Pengaduan;
use Barryvdh\DomPDF\PDF as DomPDFPDF;
use Dompdf\Adapter\PDFLib;
use Illuminate\Http\Request;
use PDF;


class LaporanController extends Controller
{
    public function index()
    {
        return view('Admin.Laporan.index');
    }


    public function getLaporan(Request $request)
    {
        if(isset($request->month)&&isset($request->status)){
            $pengaduan = Pengaduan::whereMonth('created_at', $request->month)->where('status', $request->status)->get();
        }elseif(isset($request->month)&&!isset($request->status)){
            $pengaduan = Pengaduan::whereMonth('created_at', $request->month)->get();
        }
        elseif(!isset($request->month)&&isset($request->status)){
            $pengaduan = Pengaduan::where('status', $request->status)->get();
        }
        elseif(!isset($request->month)&&!isset($request->status)){
            $pengaduan = Pengaduan::get();
        }

        return view('Admin.Laporan.index', ['pengaduan' => $pengaduan]);
    }


    public function cetakLaporan(Request $from, $to)
    {
        $pengaduan = Pengaduan::whereBetween('tgl_pengaduan', [$from, $to])->get();


        $pdf = Request::loadView('Admin.Laporan.cetak', ['pengaduan' => $pengaduan]);
        return $pdf->download('laporan-pengaduan.pdf');
    }
}
